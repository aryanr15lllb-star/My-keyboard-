package com.futurekeyboard.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
            setBackgroundColor(Color.rgb(5, 10, 18))
        }
        val button = Button(this).apply {
            text = "Open Keyboard Settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        layout.addView(button)
        setContentView(layout)
    }
}
