package com.futurekeyboard.app

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Vibrator
import android.os.VibrationEffect
import android.content.Context
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView

class FutureKeyboardService : InputMethodService() {

    private var shift = false

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 10, 8, 10)
            setBackgroundColor(Color.rgb(5, 10, 18))
        }

        val rows = listOf(
            listOf("Q","W","E","R","T","Y","U","I","O","P"),
            listOf("A","S","D","F","G","H","J","K","L"),
            listOf("⇧","Z","X","C","V","B","N","M","⌫"),
            listOf("123","😀","SPACE","↵")
        )

        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val tv = TextView(this).apply {
                    text = key
                    textSize = if (key == "SPACE") 15f else 19f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = keyBackground()
                    setPadding(2, 2, 2, 2)
                    setOnClickListener { press(key) }
                }
                val weight = if (key == "SPACE") 2.7f else if (key == "⇧" || key == "⌫" || key == "123" || key == "↵") 1.35f else 1f
                line.addView(tv, LinearLayout.LayoutParams(0, 52.dp(), weight).apply {
                    setMargins(3, 3, 3, 3)
                })
            }
            root.addView(line)
        }
        return root
    }

    private fun keyBackground(): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.rgb(18, 29, 46))
            cornerRadius = 18.dp().toFloat()
            setStroke(1.dp(), Color.rgb(55, 105, 155))
        }

    private fun press(key: String) {
        vibrate()
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "SPACE" -> ic.commitText(" ", 1)
            "↵" -> ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            "⇧" -> { shift = !shift; requestInputViewUpdate() }
            "😀" -> ic.commitText("😀", 1)
            "123" -> ic.commitText("123", 1)
            else -> ic.commitText(if (shift) key else key.lowercase(), 1)
        }
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= 26)
            v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") { v.vibrate(18) }
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
